# [MySql](https://www.bilibili.com/video/BV1Kr4y1i7ru/?share_source=copy_web&vd_source=f6539e7bf39b71f4c2fe4452f0b58ce0)

## [基础篇](mysql_base.html)
- MySQL概述
- SQL
- 函数
- 约束
- 多表查询
- 事务

## [进阶篇](mysql_adavance.html)
- 存储引擎
- 索引
- SQL优化
- 视图
- 存储过程
- 触发器
- 锁
- InnoDB核心
- MySQL管理
  
## [运维篇](mysql_operation.html)
- 日志
- 主从复制
- 分库分表
- 读写分离