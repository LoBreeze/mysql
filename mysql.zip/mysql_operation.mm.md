# [__运维篇__](mysql.html)

## __日志__
### [错误日志](pictures\picture216.png)

### 二进制日志
- [介绍](pictures\picture217.png)
- [日志格式](pictures\picture218.png)
- [日志查看](pictures\picture219.png)
- [日志删除](pictures\picture220.png)

### [查询日志](pictures\picture221.png)

### [慢查询日志](pictures\picture222.png)

## __主从复制__
- [概述](pictures\picture223.png)
- [原理](pictures\picture224.png)
- 搭建
  - 主库配置
  - 从库配置

## [__分库分表__](pictures\picture233.png)
- [中心思想](pictures\picture225.png)
- [拆分策略](pictures\picture226.png)
  - [垂直拆分](pictures\picture227.png)
  - [水平拆分](pictures\picture228.png)
- [实现技术](pictures\picture229.png)
  - [Mycat](pictures\picture230.png)
    - 一种中间件
    - [建立的是逻辑库，逻辑表](pictures\picture231.png)
    - 需配置
    - [原理](pictures\picture232.png)
    - 管理
    - 监控

## [__读写分离__](pictures\picture235.png)
- [介绍](pictures\picture234.png)
- 一主一从
- 双主双从