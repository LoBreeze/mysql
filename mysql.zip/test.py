import os
import shutil
import pyperclip

# 读取number.txt中的数字
with open("number.txt", "r") as file:
    number = int(file.read())

# 创建子目录 "pictures"（如果不存在）
os.makedirs("pictures", exist_ok=True)

# 获取当前目录下的所有文件
files = os.listdir()

# 保存文件路径的列表
file_paths = []

# 遍历所有文件
for file in files:
    # 检查文件是否是 .png 文件
    if file.endswith(".png"):
        # 构建新的文件名，例如：picture1.png, picture2.png, ...
        new_filename = "picture{}.png".format(number)

        # 移动文件到子目录 "pictures"
        shutil.move(file, os.path.join("pictures", new_filename))

        # 构建文件的相对路径
        file_path = os.path.join("pictures", new_filename)

        # 打印文件的相对路径
        print("filepath:", file_path)

        # 将文件路径添加到列表中
        file_paths.append(file_path)

        # 数字加一
        number += 1

# 将新的数字写回到number.txt文件中
with open("number.txt", "w") as file:
    file.write(str(number))

# 将文件路径复制到剪切板
pyperclip.copy('\n'.join(file_paths))
